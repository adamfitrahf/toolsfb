#!/system/xbin/bash
#!/system/xbin/botbrew
clear
echo " [!] Memulai proses mendownload "
sleep 5
echo " [!] Proses Berlangsung.. "
sleep 3
echo " [!] DON'T TURN OFF YOUR DEVICE !! "
sleep 2
apt-get update && upgrade -y
apt-get install python2 -y
apt-get install toilet -y
apt-get install php -y
apt-get install figlet
apt-get install clang 
apt-get install cowsay
apt-get install git -y
apt-get install curl -y
apt-get install openssh -y
pkg install python2
pip2 install requests
pip2 install mechanize
pkg install ruby
gem install lolcat
pkg install python
pkg install python2
pkg install nano
pkg install curl
pkg install wget
pkg install php
pkg install perl
pkg install ruby
apt update
apt upgrade
echo " [+] File pertama selesai, melanjutkan file kedua ... "
clear
bash install2.sh

sleep 5
echo " [+] peng-Installan Paket telah selesai "
sleep 3
echo " [+] Program Tools Smile Memulai .. !!! "
sleep 8
 
clear
toilet -f mono12 -F gay "Start-Up"
echo "Mod By : Clvnfrlnsyh"
cd ..
bash teamsmile.sh