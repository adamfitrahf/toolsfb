# CLONING MAIL YAHOO<br><br>
# CARA INSTALL<br>
pkg update && pkg upgrade<br>
pkg install python2<br>
pkg install pip2<br>
pip2 install requests<br>
pip2 install mechanize<br>
pkg install git<br>
git clone https://github.com/GUNAWAN18ID/cloning-yahoo.git<br>
cd cloning-yahoo<br>
python2 yahoo.py<br>
