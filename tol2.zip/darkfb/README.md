# HAI BANGSAT!
### SKUY BAKU HANTAM!
Special Thanks to KarjokPangesty a.k.a KalengKhongGuan
, Lord Deray, Ahmad Riswanto, and All my friend
