# Indonesian wordlist

Only useful for password cracking. For linguistic research, see https://github.com/ardwort/freq-dist-id

If you're wondering about the license, it's [public domain](http://creativecommons.org/licenses/publicdomain/).


