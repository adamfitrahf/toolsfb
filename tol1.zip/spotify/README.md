# CekSpoti
Checker spotify fungsinya untuk mengecek akun spotify valid atau tidak
# install
$ pkg install python<br>$ pip install requests<br>$ pkg install git

# How
   nano file
   isi seluruh akun disitu contoh " email@gmail.com|password "
   ctrl + x
   save y
   nama file biarkan ajah "file" tanpa .txt / .md
   wajib pakai pemisah email + password ~> | <~
   
contoh bisandi cek di " nano contoh "
