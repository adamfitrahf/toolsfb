#!/system/xbin/bash
clear
python2 please.py
b='\033[1m'
u='\033[4m'
bl='\E[30m'
r='\E[31m'
g='\E[32m'
bu='\E[34m'
m='\E[35m'
c='\E[36m'
w='\E[37m'
endc='\E[0m'
enda='\033[0m'
blue='\e[1;34m'
cyan='\e[1;36m'
red='\e[1;31m'

figlet TEAM SMILE | lolcat

echo "_____________________________________________________________" | lolcat
echo " TOOLS       : Team Sm:)e                  "|lolcat
echo " VERSION     : TOOLS SMILE V1.3 PRO                 "|lolcat
echo " MOD         : Clvnfrlnsyh               "|lolcat
echo " ASSOCIATE   : ◢ ◤ Team Sm:)e ◢ ◤               "|lolcat
echo " ASSOCIATE   : Sgb Team Reborn                "|lolcat
echo "_____________________________________________________________" | lolcat
date | lolcat

sleep 1

###################################################
# CTRL + C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
cd /sdcard/teamsmile
bash teamsmile.sh
}

echo ""
sleep 1
echo -e "######################################" | lolcat
echo -e "------------LIST TOOLS :--------------" | lolcat
echo -e "######################################" | lolcat
echo ""

echo -e $b "1. Tokopedia${enda}";
echo -e "============================" | lolcat
echo -e $b "2. Dark-Facebook${enda}";
echo -e "============================" | lolcat
echo -e $b "3. Oyo${enda}";
echo -e "============================" | lolcat
echo -e $b "4. Gmail-Brute${enda}";
echo -e "============================" | lolcat
echo -e $b "5. Grab${enda}";
echo -e "============================" | lolcat
echo -e $b "6. Locator${enda}";
echo -e "============================" | lolcat
echo -e $b "7. Tix-Id + Ovo${enda}";
echo -e "============================" | lolcat
echo -e $b "8. Bot Yodo${enda}";
echo -e "============================" | lolcat
echo -e $b "9. Bom E-Mail${enda}";
echo -e "============================" | lolcat
echo -e $b "10. Phishing Sheelphish${enda}";
echo -e "============================" | lolcat
echo -e $b "11. Cam Hidden SayCheese${enda}";
echo -e "============================" | lolcat
echo -e $b "12. Locater Seeker${enda}";
echo -e "============================" | lolcat
echo -e $b "13. Search Username${enda}";
echo -e "============================" | lolcat
echo -e $b "14. Spesifikasi My Phone${enda}";
echo -e "============================" | lolcat
echo -e $b "15. Spotify Checker VALID${enda}";
echo -e "============================" | lolcat
echo -e $b "16. RedHawk${enda}";
echo -e "============================" | lolcat
echo -e $b "17. Information Gathering${enda}";
echo -e "============================" | lolcat
echo -e $b "18. FbBrute${enda}";
echo -e "============================" | lolcat
echo -e $b "19. Deface Web Vuln${enda}";
echo -e "============================" | lolcat
echo -e $b "20. Yahoo-Clone Facebook${enda}";
echo -e "============================" | lolcat
echo -e $b "21. UnFriend DeathAccountFb${enda}";
echo -e "============================" | lolcat
echo -e $b "69. Info${enda}";
echo -e "============================" | lolcat
echo -e $b "0. Exit${enda}";
echo -e "============================" | lolcat
echo ""
echo -e "Select Your Number :"


read mrrm
if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
echo "Mod : Clvnfrlnsyh"
figlet "tokopedia"
php 1.php
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
echo "Mod : Clvnfrlnsyh"
toilet "Dark-Fb"
cd darkfb
python2 run.py
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
echo "\033[31;1m"
figlet "Oyo"
python 3.py
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono12 -F gay "Gmail-Brute"
echo "Mod By : Clvnfrlnsyh"
cd Gmailbrute
python2 gmail.py
fi

if
[ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f mono12 -F gay "Grab"
echo "Mod By : Clvnfrlnsyh"
python 5.py
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Locator"
echo "Mod By : Clvnfrlnsyh"
cd locator
bash locator.sh
fi

if
[ $mrrm = 7 ] || [ $mrrm = 7 ]
then
clear
toilet -f standard -F gay "Tix-Id Ovo"
echo "Mod By : Clvnfrlnsyh"
php 7.php
fi

if
[ $mrrm = 8 ] || [ $mrrm = 8 ]
then
clear
toilet -f standard -F gay "Bot Yodo"
echo "Mod By : Clvnfrlnsyh"
php 8.php
fi

if
[ $mrrm = 9 ] || [ $mrrm = 9 ]
then
clear
toilet -f standard -F gay "Bom E-Mail"
echo "Mod By : Clvnfrlnsyh"
php 9.php
fi

if [ $mrrm = 10 ] || [ $mrrm = 10 ]
then
clear
toilet -f mono12 -F gay "Phising"
echo "Mod By : Clvnfrlnsyh"
bash shellphish.sh
fi

if [ $mrrm = 11 ] || [ $mrrm = 11 ]
then
clear
toilet -f mono12 -F gay "SayCheese"
echo "Mod By : Clvnfrlnsyh"
bash saycheese.sh
fi

if [ $mrrm = 12 ] || [ $mrrm = 12 ]
then
clear
toilet -f mono12 -F gay "Seeker"
echo "Mod By : Clvnfrlnsyh"
cd termux
python seeker.py
fi

if [ $mrrm = 13 ] || [ $mrrm = 13 ]
then
clear
toilet -f mono12 -F gay "Userrecon"
echo "Mod By : Clvnfrlnsyh"
bash userrecon.sh
fi

if [ $mrrm = 14 ] || [ $mrrm = 14 ]
then
clear
toilet -f standard -F gay "iPhone"
pkg install neofetch
neofetch
fi

if [ $mrrm = 15 ] || [ $mrrm = 15 ]
then
clear
toilet -f standard -F gay "Spotify"
cd spotify
nano README.md
nano contoh
nano file
python spoti.py
fi

if [ $mrrm = 16 ] || [ $mrrm = 16 ]
then
clear
toilet -f standard -F gay "RedHawk"
cd redhawk
php rhawk.php
fi

if [ $mrrm = 17 ] || [ $mrrm = 17 ]
then
clear
toilet -f mono12 -F gay "Infog"
echo "Mod By : Clvnfrlnsyh"
cd infog
bash infog.sh
fi

if [ $mrrm = 18 ] || [ $mrrm = 18 ]
then
clear
toilet -f standard -F gay "FbBrute"
cd fbbrute
php fb.php
fi

if [ $mrrm = 19 ] || [ $mrrm = 19 ]
then
clear
echo "Mod : Clvnfrlnsyh"
figlet "Deface"
sh def.sh
fi

if [ $mrrm = 20 ] || [ $mrrm = 20 ]
then
clear
echo "Mod : Clvnfrlnsyh"
figlet "Clone-Yahoo"
cd cloning-yahoo
python2 yahoo.py
fi

if [ $mrrm = 21 ] || [ mrrm = 21 ]
then
clean
echo "Mod : Clvnfrlnsyh"
figlet "Unfriends"
cd fbun
php unfriend.php
fi

if
[ $mrrm = 69 ] || [ $mrrm = 69 ]
then
clear

figlet TEAM SMILE | lolcat

echo "Name tools : Tools Sm:)e"
sleep 1
echo "Mod: Clvnfrlnsyh"
sleep 1
echo "Version : v1.3 Pro"
sleep 1
echo "Team: ★Sgb Team Reborn★"
sleep 1
echo "Spesial Thanks To: "
echo "Allah SWT"
echo "Team Sm:)e"
echo "4:39"
echo "TheLinuxChoice"
echo "TheWhiteH4t"
echo "All Member Army Bathalion's"
echo "All Team Coder / Recode Tools"
echo "All Member Sgb Team Reborn"
sleep 1
echo "DON'T FORGET FOR SM:)E"
sleep 7
bash teamsmile.sh
fi

if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "Sign - Out"
sleep 1
echo " Berhasil "
sleep 1
exit
fi
