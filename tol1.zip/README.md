# Team Sm:)e v1.3 -Pro
## Author: github.com/Unknown240
### IG: instagram.com/calvinfirlansyah
#### Don't copy this code without give me the credits, ASSHOLE..!!!


###CHANGELOG

##Team Smile V1.3 Pro :
[+] Login
[+] New look and style
[+] Date
××× Features ×××
[+] BomSms &  Call
[+] Phising Tools
[+] Hidden Cam
[+] Locator
[+] Locator Seeker (Template)
[+] Search Username
[+] Spek Your Phone
[+] Spotify Checker
[+] RedHawk
[+] Info.Gathering
[+] Facebook Brute
[+] G-Mail Brute
[+] Deface Web Vuln
[+] Yahoo Clone
[+] Unfriend DeathAccount Facebook
[+] Password Brute 100619 Random (Brute)
[+] Password List Random (Brute)
[√] Fix Bug Bom E-Mail
[√] Fix Bug Install


##Tools Team Sm:)e v1.2 :

#Bom Sms
#Spam Call
#Phishing Tool for Instagram, Facebook, Twitter, Snapchat, Github, Yahoo, Protonmail, Google, Spotify, Netflix, Linkedin, Wordpress, Origin, Steam, Microsoft, InstaFollowers, Pinterest +1 customizable
#Cam Hidden (Access Video/Cam) 
#Locater ( Find Location (GPS))

### Features:
##  Port Forwarding using Ngrok or Serveo
## 	GPS
##  CAM
##  SSH


### Usage:
```
git clone 
cd install
  -bash install1.sh
RUN

#### THE REST TRY IT YOURSELF ####
```

#Noted :
- Pembuat tools tidak bertanggung jawab jika terjadi sesuatu baik disengaja maupun tidak.
- Terkoneksi Internet
- Untuk fitur locate / cam USAHAKAN korban meng-izinkan misal GPS/Cam [RECOMENDED CHROOME]
- Korban tidak memakai VPN
- TIDAK RECODE / MENGAMBIL ALIH COPYRIGHT SCRIPT DLL ASSHOLE
# Spam call / sms no respon?? SERVER DOWN / OFF

Update TOOLS? COMING SOON IN MY GITHUB.COM OR MY INSTAGRAM OR MY Whatsapp

BUG? Contact me

### Donate!
Support the authors:
Ovo : +62895326509469
Bank Central Asia (BCA) : 7420282731 A/N CALVIN FIRLANSYAH

More Info : 
Whatsapp +62895326509469
Telegram +62895326509469 / @clvnfrlnsyh





































COPYRIGHT 2019 @Calvinfirlansyah
TEAM SM:)E








































DON'T FORGET FOR SMILE :)
