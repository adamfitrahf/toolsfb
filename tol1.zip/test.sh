#!/system/xbin/bash
clear
echo "input"
python2 please.py
