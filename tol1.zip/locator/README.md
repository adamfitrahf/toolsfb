# Locator v1.0
## Author: github.com/thelinuxchoice/locator
## IG: instagram.com/thelinuxchoice
### Don't copy this code without give me the credits, nerd! 

Geolocator, Ip Tracker, Device Info by URL (Serveo and Ngrok).
It uses tinyurl to obfuscate the Serveo link.

![loc](https://user-images.githubusercontent.com/34893261/43586620-7a766f4a-963e-11e8-8a47-5ff4039fbda0.png)

## Legal disclaimer:

Usage of Locator for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 


### Usage:
```
git clone https://github.com/thelinuxchoice/locator
cd locator
bash locator.sh
```

### Donate!
Support the authors:

<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
